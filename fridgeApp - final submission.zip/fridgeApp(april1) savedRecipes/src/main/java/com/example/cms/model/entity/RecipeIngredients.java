package com.example.cms.model.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name = "RecipeIngredients")
public class RecipeIngredients {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Unique identifier for the recipe-ingredient relationship

    @ManyToOne
    @NotEmpty
    @JoinColumn(name = "recipeId")  // Foreign key to Recipe
    private Recipe recipe;  // The recipe this ingredient belongs to

    @ManyToOne
    @NotEmpty
    @JoinColumn(name = "ingredientId")  // Foreign key to Ingredient
    private Ingredient ingredient;  // The ingredient used in the recipe

    @Column
    @NotEmpty
    private Double quantity;  // Quantity of the ingredient needed for the recipe

    @Column
    @NotEmpty
    private String unit;

    public RecipeIngredients(Recipe recipe, Ingredient ingredient, Double quantity, String unit) {
        this.recipe = recipe;
        this.ingredient = ingredient;
        this.quantity = quantity;
        this.unit = unit;
    }
}
