package com.example.cms.model.entity;
import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

@Entity
//@NoArgsConstructor
@Getter
@Setter
@Table(name = "ownedIngredients")
public class OwnedIngredients {
    @EmbeddedId
    private OwnedIngredientsKey id;  // Composite key (userId, ingredientId)

//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;  // Unique ID for this owned ingredient record

    @ManyToOne
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private User user;  // The user who owns the ingredient

    @ManyToOne
    @JoinColumn(name = "ingredientId", insertable = false, updatable = false)
    private Ingredient ingredient;  // The ingredient owned by the user

    @Column(name = "currentQuantity")
    private double currentQuantity;  // Current quantity of the ingredient the user has

    @Column(name = "expiry")
    private LocalDate expiry;  // Date when the ingredient was bought

    // Constructor to easily initialize the OwnedIngredient
    public OwnedIngredients(User user, Ingredient ingredient, double currentQuantity, LocalDate expiry) {
        this.user = user;
        this.ingredient = ingredient;
        this.currentQuantity = currentQuantity;
        this.expiry = expiry;
        //this.desiredQuantity = desiredQuantity;
        this.id = new OwnedIngredientsKey(user.getId(), ingredient.getIngredientId()); // Use the composite key
    }

    public OwnedIngredients(){}
}