package com.example.cms.model.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
//@NoArgsConstructor
@Getter
@Setter
@Table(name = "ingredients")
public class Ingredient {
    @Id
    @NotEmpty
    private String ingredientId;

    @NotEmpty
    private String name;

    @NotEmpty
    private String foodGroup;

    @NotNull
    private int shelfLife;

    public Ingredient (String id, String name, String foodGroup, int shelfLife){
        this.ingredientId = id;
        this.name = name;
        this.foodGroup = foodGroup;
        this.shelfLife = shelfLife;
    }

    public Ingredient(){

    }
}

