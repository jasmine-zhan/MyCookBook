package com.example.cms.model.repository;

import com.example.cms.model.entity.Ingredient;
import com.example.cms.model.entity.OwnedIngredientsKey;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.cms.model.entity.OwnedIngredients;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;


public interface OwnedIngredientsRepository extends JpaRepository<OwnedIngredients, OwnedIngredientsKey> {
    void deleteById(OwnedIngredientsKey id);


    @Query(value = "SELECT id from users u " +
            "WHERE u.loggedIn = 1", nativeQuery = true)
    String getActiveUser();

    @Query(value = "SELECT i.*, oi.currentQuantity, oi.userId, oi.expiry FROM ingredients i " +
            "JOIN ownedIngredients oi ON oi.ingredientId = i.ingredientId " +
            "JOIN users u ON u.id = oi.userId " +
            "WHERE u.loggedIn = 1",
            nativeQuery = true)
    List<Object[]> userIngredientsRaw();

    //userId, ingredientId, currentQuantity
    @Query(value = "SELECT currentQuantity from ownedIngredients " +
            "WHERE userId = :userId AND ingredientId = :ingredientId", nativeQuery = true)
    double findByIngUser(@Param("userId") String userId, @Param("ingredientId") String ingredientId);

    // check expiry date
    @Query(value = "SELECT i.name from ingredients i " +
            "JOIN ownedIngredients oi ON oi.ingredientId = i.ingredientId " +
            "JOIN users u ON u.id = oi.userId " +
            "WHERE u.loggedIn = 1 AND DATEDIFF(day, :currentDate, oi.expiry) <= 0", nativeQuery = true)
    List<String> getExpiredIngredients(@Param ("currentDate") String currentDate);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM ownedIngredients " +
            "WHERE userId = :userId AND ingredientId = :ingredientId", nativeQuery = true)
    void deleteOwnedIngredient(@Param("userId") String userId, @Param("ingredientId") String ingredientId);










//    @Query(value="", nativeQuery = true)

}
