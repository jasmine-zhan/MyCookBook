package com.example.cms.controller.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class savedRecipesDto {

    private String user;
    private String recipe;


}

