package com.example.cms.model.entity;

import java.io.Serializable;
import java.util.Objects;

public class OwnedIngredientsKey implements Serializable {
    private String userId;
    private String ingredientId;

    // Default constructor, getters, setters, equals, and hashCode
    public OwnedIngredientsKey() {}

    public OwnedIngredientsKey(String userId, String ingredientId) {
        this.userId = userId;
        this.ingredientId = ingredientId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getIngredientId() {
        return ingredientId;
    }

    public void setIngredientId(String ingredientId) {
        this.ingredientId = ingredientId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OwnedIngredientsKey that = (OwnedIngredientsKey) o;
        return userId.equals(that.userId) && ingredientId.equals(that.ingredientId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, ingredientId);
    }
}

