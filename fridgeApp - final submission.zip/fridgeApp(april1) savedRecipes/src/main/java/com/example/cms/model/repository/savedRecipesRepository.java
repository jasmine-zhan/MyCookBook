package com.example.cms.model.repository;


import com.example.cms.model.entity.SavedRecipes;
import com.example.cms.model.entity.savedRecipesKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;


public interface savedRecipesRepository extends JpaRepository<SavedRecipes, savedRecipesKey> {
    void deleteById(savedRecipesKey id);


    @Query(value = "SELECT id from users u " +
            "WHERE u.loggedIn = 1", nativeQuery = true)
    String getActiveUser();

    @Query(value = "SELECT r.recipeId, u.id, r.recipeName, r.steps, r.cookTime, r.mealType, " +
            "r.cuisine, r.calories, r.servingSize FROM recipes r " +
            "JOIN savedRecipes sr ON sr.recipeId = r.recipeId " +
            "JOIN users u ON u.id = sr.userId " +
            "WHERE u.loggedIn = 1",
            nativeQuery = true)
    List<Object[]> userSavedRecipes();



    @Modifying
    @Transactional
    @Query(value = "DELETE FROM savedRecipes " +
            "WHERE userId = :userId AND recipeId = :recipeId", nativeQuery = true)
    void deleteSavedRecipes(@Param("userId") String userId, @Param("recipeId") String recipeId);









//    @Query(value="", nativeQuery = true)

}
