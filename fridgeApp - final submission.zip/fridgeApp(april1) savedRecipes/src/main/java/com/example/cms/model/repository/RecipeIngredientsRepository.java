package com.example.cms.model.repository;


import com.example.cms.model.entity.Recipe;
import com.example.cms.model.entity.RecipeIngredients;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecipeIngredientsRepository extends JpaRepository<RecipeIngredients, Long> {

    @Query(value = "SELECT ingredientId FROM RecipeIngredients WHERE recipeId = :recipeId", nativeQuery = true)
    List<String> findIngredientID(@Param("recipeId") Recipe recipeId);

}
