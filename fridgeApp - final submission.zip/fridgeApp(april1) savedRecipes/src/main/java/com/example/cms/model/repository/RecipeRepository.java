package com.example.cms.model.repository;

import com.example.cms.model.entity.Recipe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecipeRepository extends JpaRepository<Recipe, String> {
    @Query(value = "SELECT recipeId FROM recipes WHERE recipeName = :recipeName", nativeQuery = true)
    String findRecipeByName(@Param("recipeName") String recipeName);

//@Query(value = "SELECT r.recipeId, r.recipeName, " +
//        "    (SELECT COUNT(*) FROM recipeIngredients ri2 WHERE ri2.recipeId = r.recipeId) AS total_ingredients_needed, " +
//        "    COUNT(DISTINCT ui.ingredientId) AS total_ingredients_user_has " +
//        "FROM recipes r " +
//        "LEFT JOIN recipeIngredients ri ON r.recipeId = ri.recipeId " +
//        "LEFT JOIN ownedIngredients ui ON ri.ingredientId = ui.ingredientId " +
//        "LEFT JOIN users u ON ui.userId = u.id " +
//        "WHERE u.loggedIn = 1 " +
//        "GROUP BY r.recipeId, r.recipeName " +
//        "HAVING (COUNT(DISTINCT ui.ingredientId) * 100.0 / " +
//        "        (SELECT COUNT(*) FROM recipeIngredients ri2 WHERE ri2.recipeId = r.recipeId)) >= :threshold",
//        nativeQuery = true)
//List<Object[]> findThresholdRecipes(@Param("threshold") double threshold);


    @Query(value = "SELECT r.recipeId, r.recipeName, r.steps, r.cookTime, r.mealType, " +
            "r.cuisine, r.calories, r.servingSize " +
            "FROM recipes r " +
            "WHERE r.recipeId = :recipeId",
            nativeQuery = true)
    List<Object[]> getRecipeDetails(@Param("recipeId") String recipeId);


    @Query(value = "SELECT recipeId FROM recipes WHERE recipeName = :recipeName", nativeQuery = true)
    String findRecipeId(@Param("recipeName") String ingredientName);



    @Query(value = "SELECT r.recipeId, r.recipeName, ui.userId, " +
            "    (SELECT SUM(ri2.quantity) FROM recipeIngredients ri2 WHERE ri2.recipeId = r.recipeId) AS total_quantity_needed, " +
            "    SUM(CASE WHEN ui.ingredientId IS NOT NULL THEN LEAST(ri.quantity, ui.currentQuantity) ELSE 0 END) AS total_quantity_user_has, r.mealType, r.cuisine " +
            "FROM recipes r " +
            "LEFT JOIN recipeIngredients ri ON r.recipeId = ri.recipeId " +
            "LEFT JOIN ownedIngredients ui ON ri.ingredientId = ui.ingredientId " +
            "LEFT JOIN users u ON ui.userId = u.id " +
            "WHERE u.loggedIn = 1 " +
            "GROUP BY r.recipeId, r.recipeName " +
            "HAVING (SUM(CASE WHEN ui.ingredientId IS NOT NULL THEN LEAST(ri.quantity, ui.currentQuantity) ELSE 0 END) * 100.0 / " +
            "        (SELECT SUM(ri2.quantity) FROM recipeIngredients ri2 WHERE ri2.recipeId = r.recipeId)) >= :threshold",
            nativeQuery = true)
    List<Object[]> findThresholdRecipes(@Param("threshold") double threshold);




}
