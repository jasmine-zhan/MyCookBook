package com.example.cms.model.entity;

import java.io.Serializable;
import java.util.Objects;

public class savedRecipesKey implements Serializable {
    private String userId;
    private String recipeId;

    // Default constructor, getters, setters, equals, and hashCode
    public savedRecipesKey() {}

    public savedRecipesKey(String userId, String recipeId) {
        this.userId = userId;
        this.recipeId = recipeId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        savedRecipesKey that = (savedRecipesKey) o;
        return userId.equals(that.userId) && recipeId.equals(that.recipeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, recipeId);
    }
}

