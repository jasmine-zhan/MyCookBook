package com.example.cms.model.entity;

import com.example.cms.model.repository.UserRepository;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity

@Getter
@Setter
@Table(name = "recipes")
public class Recipe {
    @Id
    @NotEmpty
    private String recipeId;

    @NotEmpty
    private String recipeName;

    //@NotEmpty
    private String steps;

    //@NotEmpty
    private int cookTime;

    //@NotEmpty
    private String mealType;

    //@NotEmpty
    private String cuisine;

    //@NotEmpty
    private int calories;

    //@NotEmpty
    private int servingSize;

//    @ElementCollection
//    @CollectionTable(name = "cooked_recipes", joinColumns = @JoinColumn(name = "recipeId"))
//    private Set<CookedRecipe> usersWhoCooked = new HashSet<>();

//    @OneToMany(mappedBy = "recipe")
//    private Set<CookedRecipe> cookedRecipes;  // Relationship with CookedRecipe

    // Bi-directional Many-to-Many relationship with User
//  //  @ManyToMany(mappedBy = "recipes")  // 'recipes' is the field in the User entity
//  private Set<User> usersWhoCooked;  // Users who have cooked this recipe

    public Recipe(String recipeId, String recipeName, String steps, int cookTime, String cuisine, int calories, int servingSize){
        this.recipeId = recipeId;
        this.recipeName = recipeName;
        this.steps = steps;
        this.cookTime = cookTime;
        this.cuisine = cuisine;
        this.calories = calories;
        this.servingSize = servingSize;
    }

    public Recipe(){

    }


//    // Method to get all users who have cooked this recipe
//    public List<User> getUsersWhoCooked() {
//        List<User> users = new ArrayList<>();
//
//        for (CookedRecipe cookedRecipe : cookedRecipes) {
//            // Assuming you have a User repository to fetch User by userId
//            // You would ideally inject a UserRepository into this class and use it to fetch users
//            User user = userRepository.findById(cookedRecipe.getUserId()).orElse(null);
//            if (user != null) {
//                users.add(user);
//            }
//        }
//
//        return users;
//    }
}

