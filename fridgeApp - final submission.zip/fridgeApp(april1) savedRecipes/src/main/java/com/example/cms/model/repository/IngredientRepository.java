package com.example.cms.model.repository;
import com.example.cms.model.entity.Ingredient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IngredientRepository extends JpaRepository<Ingredient, String> {

//    @Query(value = "SELECT i.ingredientId FROM ingredients i " +
//            "RIGHT JOIN ownedIngredients oi ON oi.ingredientId = i.ingredientId " +
//            "JOIN users u ON u.id = oi.userId " +
//            "WHERE u.loggedIn = 1 AND i.name = :ingredientName",
//            nativeQuery = true)
    @Query(value = "SELECT ingredientId FROM ingredients WHERE name = :ingredientName", nativeQuery = true)
    String findIngredientID(@Param("ingredientName") String ingredientName);

//    @Query("SELECT COUNT(ingredientId)+1 From ingredients.ingredientId")
//    int generateNewIngredientNum();

    // PASTED!
    @Query(value = "SELECT name FROM ingredients WHERE ingredientId IN :ingredientId", nativeQuery = true)
    List<String> findIngredientName(@Param("ingredientId") List<String> ingredientId);

    @Query(value = "SELECT COALESCE(MAX(CAST(SUBSTRING(ingredientId, 2) AS SIGNED)), 0) + 1 FROM ingredients", nativeQuery = true)
    int generateNewIngredientNum();


}
