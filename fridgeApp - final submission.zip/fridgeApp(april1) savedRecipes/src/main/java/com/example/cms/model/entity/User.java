package com.example.cms.model.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity

@Getter
@Setter
@Table(name = "users")
public class User {
    @Id
    private String id;

    @NotEmpty
    private String firstName;

    @NotEmpty
    private String lastName;

    // password
    @NotNull
    private String password;

    @Email
    @NotEmpty
    private String email;

    @NotNull
    private int loggedIn;

//    @ElementCollection
//    @CollectionTable(name = "cooked_recipes", joinColumns = @JoinColumn(name = "userId"))
//    private Set<CookedRecipe> cookedRecipes = new HashSet<>();

    // Bi-directional Many-to-Many relationship with Recipe
//    @ManyToMany
//    @JoinTable(
//            name = "recipesCooked",  // Join table name
//            joinColumns = @JoinColumn(name = "userId"),  // Foreign key to User
//            inverseJoinColumns = @JoinColumn(name = "recipeId")  // Foreign key to Recipe
//    )
//    private Set<Recipe> recipesCookedByUser;  // Recipes cooked by this user

    public User(String id, String password, String firstName, String lastName, String email){
        this.id = id;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.loggedIn = 1;
    }


    public User(){

    }
}


