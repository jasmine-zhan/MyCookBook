package com.example.cms.model.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
//@NoArgsConstructor
@Getter
@Setter
@Table(name = "savedRecipes")
public class SavedRecipes {
    @EmbeddedId
    private savedRecipesKey id;  // Composite key (userId, recipeId)

    @ManyToOne
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "recipeId", insertable = false, updatable = false)
    private Recipe recipe;



    public SavedRecipes(User user, Recipe recipe) {
        this.user = user;
        this.recipe = recipe;
        this.id = new savedRecipesKey(user.getId(), recipe.getRecipeId()); // Use the composite key
    }

    public SavedRecipes() {

    }

}