package com.example.cms.model.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Getter
@Setter
public class CookedRecipe implements Serializable {

    @Column(name = "userId")
    String userId;

    @Column(name = "recipeId")
    String recipeId;


    @Override
    public int hashCode() {
        String concatString = String.valueOf(userId.hashCode()) + String.valueOf(recipeId.hashCode());
        return concatString.hashCode();
    }
    public CookedRecipe(){}

    public CookedRecipe(String userId, String recipeId){
        this.setUserId(userId);
        this.setRecipeId(recipeId);
    }


    @Override
    public boolean equals(Object o) {
        if (o == null){
            return false;
        }
        if (o == this)
            return true;
        if (!(o instanceof CookedRecipe))
            return false;
        CookedRecipe other = (CookedRecipe) o;
        return userId.equals(other.userId) && recipeId.equals(other.recipeId);
    }

}
