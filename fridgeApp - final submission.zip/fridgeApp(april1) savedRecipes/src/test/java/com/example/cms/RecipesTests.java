package com.example.cms;

import com.example.cms.controller.UserController;
import com.example.cms.model.entity.Recipe;
import com.example.cms.model.entity.User;
import com.example.cms.model.repository.RecipeRepository;
import com.example.cms.model.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class RecipesTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private UserRepository userRepository;

	@Test
	void getRecipe() throws Exception{
		MockHttpServletResponse response = mockMvc.perform(get("/recipes/R001"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());

		ObjectNode receivedJson = objectMapper.readValue(response.getContentAsString(), ObjectNode.class);
		assertEquals("R001", receivedJson.get("recipeId").textValue());
		assertEquals("Spaghetti Aglio e Olio", receivedJson.get("recipeName").textValue());
		assertEquals("Cook spaghetti. Heat olive oil, garlic, red pepper flakes, and parsley in a pan. Toss cooked spaghetti in the oil mixture.", receivedJson.get("steps").textValue());
	}

	@Test
	void getRecipesThresholdCanMake() throws Exception{ //logs in a user who has 75% of ingredients needed to make steak and potatoes
		// log in User U002
		String userEmail = "donkey.donkey@shrek.com";
		String inputPassword = "DonkeyD123!";
		String userId = "U010";

		UserController uc = new UserController(userRepository);

		// login U002
		User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));


		MockHttpServletResponse response = mockMvc.perform(get("/recipes/filter/75"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());

		// Deserialize response as an array of arrays (List<Object[]>)
		ObjectMapper objectMapper = new ObjectMapper();
		List<List<Object>> receivedJson = objectMapper.readValue(response.getContentAsString(), List.class);

		// Verify the first recipe in the list
		List<Object> firstRecipe = receivedJson.get(0);
		assertEquals("R016", firstRecipe.get(0));
		assertEquals("Steak and Potatoes", firstRecipe.get(1));
		assertEquals(4, firstRecipe.get(3));
		assertEquals(3, firstRecipe.get(4));

	}

	@Test
	void getRecipesThresholdCanNotMake() throws Exception{ //logs in a user who doesnt have all ingredients needed to make any recipe
		// log in User U002
		String userEmail = "donkey.donkey@shrek.com";
		String inputPassword = "DonkeyD123!";
		String userId = "U010";

		UserController uc = new UserController(userRepository);

		// login U002
		User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));


		MockHttpServletResponse response = mockMvc.perform(get("/recipes/filter/100"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());

		// Deserialize response as an array of arrays (List<Object[]>)
		ObjectMapper objectMapper = new ObjectMapper();
		List<List<Object>> receivedJson = objectMapper.readValue(response.getContentAsString(), List.class);

		// Verify the first recipe in the list
		//List<Object> firstRecipe = receivedJson.get(0);
		assertTrue(receivedJson.isEmpty());

	}

	@Test
	void addRecipe() throws Exception{

		ObjectNode recipeJson = objectMapper.createObjectNode();
		recipeJson.put("recipeId", "R999");
		recipeJson.put("recipeName", "Test");
		recipeJson.put("steps", "testing");
		recipeJson.put("cookTime", 10L);
		recipeJson.put("mealType", "testing");
		recipeJson.put("cuisine", "testinggg");
		recipeJson.put("calories", 50L);
		recipeJson.put("servingSize", 5L);

		MockHttpServletResponse response = mockMvc.perform(
						post("/recipes").
								contentType("application/json").
								content(recipeJson.toString()))
				.andReturn().getResponse();

		// assert HTTP code of response is 200 OK
		assertEquals(200, response.getStatus());

		// Assert student with id 8888 exists in our repository and then get the student object
		assertTrue(recipeRepository.findById("R999").isPresent());
		Recipe addedRecipe = recipeRepository.findById("R999").get();

		// Assert the details of the students are correct
		assertEquals("R999", addedRecipe.getRecipeId());
		assertEquals("Test", addedRecipe.getRecipeName());
		assertEquals("testing", addedRecipe.getSteps());
	}

	@Test
	void updateRecipe() throws Exception {
		//INSERT INTO recipes (recipeId, recipeName, steps, cookTime, mealType, cuisine, calories, servingSize)
		//('R002', 'Beef Tacos', 'Cook ground beef with onions and garlic. Assemble with tortillas, cheese, lettuce, and salsa.', 20, 'Dinner', 'Mexican', 600, 3),

		// Step 2: Prepare the updated user object
		Recipe updatedRecipe = new Recipe();
		updatedRecipe.setRecipeId("R002");
		updatedRecipe.setRecipeName("updatedRecipeName");
		updatedRecipe.setSteps("new steps");


		// Step 3: Perform the update request
		MockHttpServletResponse response = mockMvc.perform(
						put("/recipes/R002")
								.contentType("application/json")
								.content(asJsonString(updatedRecipe)))  // Ensure you have a method to convert object to JSON string
				.andReturn().getResponse();

		// Step 4: Assert the response status
		assertEquals(200, response.getStatus());

		// Step 5: Verify the user was updated in the repository
		Recipe fetchedRecipe = recipeRepository.findById("R002").orElseThrow();
		assertEquals("updatedRecipeName", fetchedRecipe.getRecipeName());
		assertEquals("new steps", fetchedRecipe.getSteps());

	}

	// Utility method to convert object to JSON string
	private String asJsonString(Object obj) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Test
	void deleteRecipe() throws Exception{
		Recipe r = new Recipe();
		r.setRecipeId("R666");
		r.setRecipeName("test");
		r.setSteps("test");
		recipeRepository.save(r);

		MockHttpServletResponse response = mockMvc.perform(
						delete("/recipes/R666").
								contentType("application/json"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());
		assertTrue(recipeRepository.findById("R666").isEmpty());
	}
	//('R053', 'Baked Ziti', 'Cook ziti pasta. Make a marinara sauce with tomatoes, garlic, and herbs. Combine pasta with sauce, cheese, and bake.', 40, 'Dinner', 'Italian', 700, 4);

}