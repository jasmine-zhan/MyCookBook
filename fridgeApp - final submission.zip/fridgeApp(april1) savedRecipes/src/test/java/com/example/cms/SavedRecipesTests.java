package com.example.cms;

import com.example.cms.controller.OwnedIngredientsController;
import com.example.cms.controller.UserController;
import com.example.cms.controller.dto.OwnedIngredientsDto;
import com.example.cms.controller.savedRecipeController;
import com.example.cms.model.entity.Ingredient;
import com.example.cms.model.entity.OwnedIngredients;
import com.example.cms.model.repository.savedRecipesRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.cms.model.entity.User;
import com.example.cms.model.repository.OwnedIngredientsRepository;
import com.example.cms.model.repository.UserRepository;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class SavedRecipesTests {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private savedRecipesRepository repository;

    @Test
    void getSavedRecipes() throws Exception{
        // log in User U002
        String userEmail = "woody.pride@toy.com";
        String inputPassword = "Woody!2023";
        String userId = "U002";

        UserController uc = new UserController(userRepository);

        // login U002
        User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));

        MockHttpServletResponse response = mockMvc.perform(get("/SavedRecipes/getAllSaved"))
                .andReturn().getResponse();

        assertEquals(200, response.getStatus());

        ObjectMapper objectMapper = new ObjectMapper();
        List<ObjectNode> receivedJson = objectMapper.readValue(response.getContentAsString(), new TypeReference<List<ObjectNode>>() {});

        ObjectNode firstRecipe = receivedJson.get(0);
        assertEquals("U002", firstRecipe.get("userId").textValue());
        assertEquals("R001", firstRecipe.get("recipeId").textValue());
    }

    // Utility method to convert object to JSON string
    private String asJsonString(Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void addSavedRecipe() throws Exception{
        // log in User U002
        String userEmail = "buzz.lightyear@space.com";
        String inputPassword = "BuzzLight#2020";
        String userId = "U003";

        UserController uc = new UserController(userRepository);

        // login U002
        User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));

        ObjectNode oiJson = objectMapper.createObjectNode();
        oiJson.put("user", "U003");
        oiJson.put("recipe", "Spaghetti Aglio e Olio");

        MockHttpServletResponse response = mockMvc.perform(
                        post("/SavedRecipes/addSaved").
                                contentType("application/json").
                                content(oiJson.toString()))
                .andReturn().getResponse();

        assertEquals(200, response.getStatus());


        // get owned ingredients for the logged-in user (U002)
        List<Object[]> result = repository.userSavedRecipes();

        // assert that the data is correctly retrieved
        assertNotNull(result);

        // query database to get the expected owned ingredients for user U002
        Object[] actual = result.get(0);
        for (int i=0; i<actual.length; i++){
            System.out.println(actual[i]);
        }


        assertEquals("U003", actual[1]);
        assertEquals("R001", actual[0]);
    }


    @Test
    void deleteOwnedIngredient() throws Exception{
        String userEmail = "buzz.lightyear@space.com";
        String inputPassword = "BuzzLight#2020";

        UserController uc = new UserController(userRepository);
        savedRecipeController src = new savedRecipeController(repository);

        // login U003
        User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));

        // get current num of owned ingredients
        int numSaved = repository.userSavedRecipes().size();
        System.out.print(numSaved);

        // add new ingredient to owned ingredients
        ObjectNode oiJson = objectMapper.createObjectNode();
        oiJson.put("user", "U003");
        oiJson.put("recipe", "Beef Tacos");
        System.out.print(repository.userSavedRecipes().size());

        MockHttpServletResponse add = mockMvc.perform(
                        post("/SavedRecipes/addSaved").
                                contentType("application/json").
                                content(oiJson.toString()))
                .andReturn().getResponse();

        System.out.print(repository.userSavedRecipes().size());

        // delete new ingredient
        MockHttpServletResponse response = mockMvc.perform(
                        delete("/SavedRecipes/removeSaved/U003/R002").
                                contentType("application/json"))
                .andReturn().getResponse();

        // check that length after delete = length before add
        assertEquals(200, response.getStatus());
        assertEquals(repository.userSavedRecipes().size(), numSaved);

        System.out.print(repository.userSavedRecipes().size());
    }

}
