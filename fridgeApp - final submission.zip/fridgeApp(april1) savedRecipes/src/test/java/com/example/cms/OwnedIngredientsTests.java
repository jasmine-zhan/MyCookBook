package com.example.cms;

import com.example.cms.controller.OwnedIngredientsController;
import com.example.cms.controller.UserController;
import com.example.cms.controller.dto.OwnedIngredientsDto;
import com.example.cms.model.entity.Ingredient;
import com.example.cms.model.entity.OwnedIngredients;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.cms.model.entity.User;
import com.example.cms.model.repository.OwnedIngredientsRepository;
import com.example.cms.model.repository.UserRepository;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class OwnedIngredientsTests {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private OwnedIngredientsRepository ownedIngredientsRepository;

	@Test
	void getOwnedIngredients() throws Exception{
		// log in User U002
		String userEmail = "woody.pride@toy.com";
		String inputPassword = "Woody!2023";
		String userId = "U002";

		UserController uc = new UserController(userRepository);

		// login U002
		User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));

		MockHttpServletResponse response = mockMvc.perform(get("/OwnedIngredients/getAllOwned"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());

		ObjectMapper objectMapper = new ObjectMapper();
		List<ObjectNode> receivedJson = objectMapper.readValue(response.getContentAsString(), new TypeReference<List<ObjectNode>>() {});

		ObjectNode firstIngredient = receivedJson.get(0);
		assertEquals("U002", firstIngredient.get("user").textValue());
		assertEquals("I001", firstIngredient.get("ingredient").textValue());
		assertEquals(1L, firstIngredient.get("currentQuantity").intValue());
		assertEquals("2025-03-20", firstIngredient.get("bestBefore").textValue());
	}

	// Utility method to convert object to JSON string
	private String asJsonString(Object obj) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Test
	void addOwnedIngredient() throws Exception{
		// log in User U002
		String userEmail = "buzz.lightyear@space.com";
		String inputPassword = "BuzzLight#2020";
		String userId = "U003";

		UserController uc = new UserController(userRepository);

		// login U002
		User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));

		ObjectNode oiJson = objectMapper.createObjectNode();
		oiJson.put("user", "U003");
		oiJson.put("ingredientName", "Lemon");
		oiJson.put("currentQuantity", "1");

		MockHttpServletResponse response = mockMvc.perform(
						post("/OwnedIngredients/ingredientName").
								contentType("application/json").
								content(oiJson.toString()))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());


		// get owned ingredients for the logged-in user (U002)
		List<Object[]> result = ownedIngredientsRepository.userIngredientsRaw();

		// assert that the data is correctly retrieved
		assertNotNull(result);

		// query database to get the expected owned ingredients for user U002
		Object[] actual = result.get(0);

		assertEquals("U003", actual[5]);
		assertEquals("I019", actual[0]);
		assertEquals(1.0, actual[4]);
		LocalDate expiry = LocalDate.now().plusDays(10);
		assertEquals(expiry.toString(), actual[6].toString());
	}

	@Test
	void updateIngredientQuantity() throws Exception {
//        INSERT INTO ingredients (ingredientId, name, foodGroup, shelfLife) VALUES
//                ('I001', 'Olive Oil', 'Fats', 180),

		ObjectNode oiJson = objectMapper.createObjectNode();
		oiJson.put("user", "U001");
		oiJson.put("ingredientName", "Lemon");
		oiJson.put("currentQuantity", "4");

		// Step 3: Perform the update request
		MockHttpServletResponse response = mockMvc.perform(
						put("/OwnedIngredients/69.0")
								.contentType("application/json")
								.content(oiJson.toString()))  // Ensure you have a method to convert object to JSON string
				.andReturn().getResponse();


		// Step 4: Assert the response status
		assertEquals(200, response.getStatus());

		// Step 5: Verify the user was updated in the repository
		double updatedQuantity = ownedIngredientsRepository.findByIngUser("U001", "I019");

		assertEquals(69.0, updatedQuantity);
	}

	@Test
	void deleteOwnedIngredient() throws Exception{
		String userEmail = "buzz.lightyear@space.com";
		String inputPassword = "BuzzLight#2020";

		UserController uc = new UserController(userRepository);
		OwnedIngredientsController oic = new OwnedIngredientsController(ownedIngredientsRepository);

		// login U003
		User loggedInUser = uc.loginUser(Map.of("email", userEmail, "password", inputPassword));

		// get current num of owned ingredients
		int numOwned = ownedIngredientsRepository.userIngredientsRaw().size();

		// add new ingredient to owned ingredients
		ObjectNode oiJson = objectMapper.createObjectNode();
		oiJson.put("user", "U003");
		oiJson.put("ingredientName", "Ground Beef");
		oiJson.put("currentQuantity", "1");

		MockHttpServletResponse response = mockMvc.perform(
						post("/OwnedIngredients/ingredientName").
								contentType("application/json").
								content(oiJson.toString()))
				.andReturn().getResponse();

		// delete new ingredient
		MockHttpServletResponse response2 = mockMvc.perform(
						delete("/OwnedIngredients/delete/U003/I004").
								contentType("application/json"))
				.andReturn().getResponse();

		// check that length after delete = length before add
		assertEquals(200, response2.getStatus());
		assertEquals(ownedIngredientsRepository.userIngredientsRaw().size(), numOwned);
	}

}
