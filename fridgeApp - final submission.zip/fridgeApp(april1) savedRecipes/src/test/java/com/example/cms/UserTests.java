package com.example.cms;

import com.example.cms.model.entity.User;
import com.example.cms.model.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class UserTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private UserRepository userRepository;

	@Test
	void getUser() throws Exception{
		MockHttpServletResponse response = mockMvc.perform(get("/users/U002"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());

		ObjectNode receivedJson = objectMapper.readValue(response.getContentAsString(), ObjectNode.class);
		assertEquals("U002", receivedJson.get("id").textValue());
		assertEquals("Woody!2023", receivedJson.get("password").textValue());
		assertEquals("Woody", receivedJson.get("firstName").textValue());
		assertEquals("Pride", receivedJson.get("lastName").textValue());
		//assertEquals(1L, receivedJson.get("loggedIn").intValue());
	}


	@Test
	void addUser() throws Exception{

		ObjectNode userJson = objectMapper.createObjectNode();
		userJson.put("id", "U999");
		userJson.put("password", "Emmet123!");
		userJson.put("firstName", "Tanya");
		userJson.put("lastName", "Helen");
		userJson.put("email", "first@last.com");

		MockHttpServletResponse response = mockMvc.perform(
						post("/users").
								contentType("application/json").
								content(userJson.toString()))
				.andReturn().getResponse();

		// assert HTTP code of response is 200 OK
		assertEquals(200, response.getStatus());

		// Assert student with id 8888 exists in our repository and then get the student object
		assertTrue(userRepository.findById("U999").isPresent());
		User addedUser = userRepository.findById("U999").get();

		// Assert the details of the students are correct
		assertEquals("U999", addedUser.getId());
		assertEquals("Emmet123!", addedUser.getPassword());
		assertEquals("Tanya", addedUser.getFirstName());
		assertEquals("Helen", addedUser.getLastName());
		assertEquals("first@last.com", addedUser.getEmail());
	}

	@Test
	void updateUser() throws Exception {


		// Step 2: Prepare the updated user object
		User updatedUser = new User();
		updatedUser.setId("U001");
		updatedUser.setFirstName("updatedFirst");
		updatedUser.setLastName("updatedLast");
		updatedUser.setEmail("updated@last.com");
		updatedUser.setPassword("Emmet123!");

		// Step 3: Perform the update request
		MockHttpServletResponse response = mockMvc.perform(
						put("/users/U001")
								.contentType("application/json")
								.content(asJsonString(updatedUser)))  // Ensure you have a method to convert object to JSON string
				.andReturn().getResponse();

		// Step 4: Assert the response status
		assertEquals(200, response.getStatus());

		// Step 5: Verify the user was updated in the repository
		User fetchedUser = userRepository.findById("U001").orElseThrow();
		assertEquals("updatedFirst", fetchedUser.getFirstName());
		assertEquals("updatedLast", fetchedUser.getLastName());
		assertEquals("updated@last.com", fetchedUser.getEmail());
		assertEquals("Emmet123!", fetchedUser.getPassword());
	}

	// Utility method to convert object to JSON string
	private String asJsonString(Object obj) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}


	@Test
	void deleteUser() throws Exception{
		User u = new User();
		u.setId("U888");
		u.setFirstName("first");
		u.setLastName("last");
		u.setEmail("first@last.com");
		u.setPassword("Emmet123!");
		userRepository.save(u);

		MockHttpServletResponse response = mockMvc.perform(
						delete("/users/delete/U888").
								contentType("application/json"))
				.andReturn().getResponse();

		assertEquals(200, response.getStatus());
		assertTrue(userRepository.findById("U888").isEmpty());
	}

}