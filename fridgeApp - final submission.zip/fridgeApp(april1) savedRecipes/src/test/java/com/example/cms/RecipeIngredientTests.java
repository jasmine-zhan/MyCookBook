package com.example.cms;

import com.example.cms.model.entity.Ingredient;
import com.example.cms.model.repository.IngredientRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc

public class RecipeIngredientTests {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private IngredientRepository repository;

    @Test
    void getIngredient() throws Exception{
        MockHttpServletResponse response = mockMvc.perform(get("/RecipeIngredients/findRecipeIngredients/R001"))
                .andReturn().getResponse();

        assertEquals(200, response.getStatus());
        String[] actual = {"I001", "I002", "I018", "I016"};

        ArrayNode receivedJson = objectMapper.readValue(response.getContentAsString(), ArrayNode.class);
        for (int i = 0; i< receivedJson.size(); i++){
            assertEquals(actual[i], receivedJson.get(i).textValue());
        }
    }

}