package com.example.cms;

import com.example.cms.model.entity.Ingredient;
import com.example.cms.model.entity.Recipe;
import com.example.cms.model.repository.IngredientRepository;
import com.example.cms.model.repository.RecipeRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc

public class IngredientTests {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private IngredientRepository repository;

    @Test
    void getIngredient() throws Exception{
//        INSERT INTO ingredients (ingredientId, name, foodGroup, shelfLife) VALUES
//                ('I001', 'Olive Oil', 'Fats', 180),
        MockHttpServletResponse response = mockMvc.perform(get("/ingredients/I001"))
                .andReturn().getResponse();

        assertEquals(200, response.getStatus());

        ObjectNode receivedJson = objectMapper.readValue(response.getContentAsString(), ObjectNode.class);
        assertEquals("I001", receivedJson.get("ingredientId").textValue());
        assertEquals("Olive Oil", receivedJson.get("name").textValue());
        assertEquals("Fats", receivedJson.get("foodGroup").textValue());
        assertEquals(180L, receivedJson.get("shelfLife").intValue());

    }

    @Test
    void addIngredient() throws Exception{

        ObjectNode ingredientJson = objectMapper.createObjectNode();
        ingredientJson.put("ingredientId", "R999");
        ingredientJson.put("name", "Test");
        ingredientJson.put("foodGroup", "testing");
        ingredientJson.put("shelfLife", 10L);

        MockHttpServletResponse response = mockMvc.perform(
                        post("/ingredients/newIngredient").
                                contentType("application/json").
                                content(ingredientJson.toString()))
                .andReturn().getResponse();

        // assert HTTP code of response is 200 OK
        assertEquals(200, response.getStatus());

        // Assert student with id 8888 exists in our repository and then get the student object
        assertTrue(repository.findById("R999").isPresent());
        Ingredient addedIngredient = repository.findById("R999").get();

        // Assert the details of the students are correct
        assertEquals("R999", addedIngredient.getIngredientId());
        assertEquals("Test", addedIngredient.getName());
        assertEquals("testing", addedIngredient.getFoodGroup());
        assertEquals(10L, addedIngredient.getShelfLife());
    }

    @Test
    void updateIngredient() throws Exception {
//        INSERT INTO ingredients (ingredientId, name, foodGroup, shelfLife) VALUES
//                ('I001', 'Olive Oil', 'Fats', 180),

        // prepare the updated user object
        Ingredient updatedIngredient = new Ingredient();
        updatedIngredient.setIngredientId("I002");
        updatedIngredient.setName("New");
        updatedIngredient.setFoodGroup("new");

        // perform the update request
        MockHttpServletResponse response = mockMvc.perform(
                        put("/ingredients/I002")
                                .contentType("application/json")
                                .content(asJsonString(updatedIngredient)))  // Ensure you have a method to convert object to JSON string
                .andReturn().getResponse();


        // assert the response status
        assertEquals(200, response.getStatus());

        // verify the user was updated in the repository
        Ingredient fetchedIngredient = repository.findById("I002").orElseThrow();
        assertEquals("New", fetchedIngredient.getName());
        assertEquals("new", fetchedIngredient.getFoodGroup());

    }

    // Utility method to convert object to JSON string
    private String asJsonString(Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void deleteIngredient() throws Exception{
        Ingredient I = new Ingredient();
        I.setIngredientId("I909");
        I.setName("test");
        I.setShelfLife(10);
        I.setFoodGroup("test");
        repository.save(I);

        MockHttpServletResponse response = mockMvc.perform(
                        delete("/ingredients/I909").
                                contentType("application/json"))
                .andReturn().getResponse();

        assertEquals(200, response.getStatus());
        assertTrue(repository.findById("I909").isEmpty());
    }
}